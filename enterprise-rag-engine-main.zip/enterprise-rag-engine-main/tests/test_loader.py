import pytest
from unittest.mock import MagicMock, patch
from pathlib import Path
from src.loader import (
    validate_pdf,
    extract_text_from_pdf,
    split_pages_into_chunks,
    DocumentProcessingError
)
from src.config import Config

def test_validate_pdf_success(mock_pdf_file):
    """Verifies that a valid PDF file passes validation checks."""
    # Should not raise any exceptions
    validate_pdf(mock_pdf_file)


def test_validate_pdf_not_found():
    """Verifies that a non-existent file path raises DocumentProcessingError."""
    non_existent = Path("does_not_exist.pdf")
    with pytest.raises(DocumentProcessingError, match="File not found"):
        validate_pdf(non_existent)


def test_validate_pdf_invalid_extension(mock_invalid_file):
    """Verifies that a non-PDF file extension raises DocumentProcessingError."""
    with pytest.raises(DocumentProcessingError, match="Unsupported file type"):
        validate_pdf(mock_invalid_file)


def test_validate_pdf_too_large(tmp_path):
    """Verifies that a file exceeding MAX_FILE_SIZE_MB raises DocumentProcessingError."""
    large_file = tmp_path / "large.pdf"
    # Create a dummy file larger than the configured limit
    # We can temporarily override the Config limit to 0 for testing size limit violation
    large_file.write_text("dummy content")
    
    original_limit = Config.MAX_FILE_SIZE_MB
    Config.MAX_FILE_SIZE_MB = 0.000001 # Extremely small limit
    
    try:
        with pytest.raises(DocumentProcessingError, match="exceeds the maximum allowed limit"):
            validate_pdf(large_file)
    finally:
        Config.MAX_FILE_SIZE_MB = original_limit


@patch("src.loader.PdfReader")
def test_extract_text_from_pdf_success(mock_reader_class, mock_pdf_file):
    """Tests text extraction from PDF by mocking PdfReader pages."""
    # Set up mock reader behavior
    mock_reader = MagicMock()
    mock_page1 = MagicMock()
    mock_page1.extract_text.return_value = "Page 1 Content"
    mock_page2 = MagicMock()
    mock_page2.extract_text.return_value = "Page 2 Content"
    
    mock_reader.pages = [mock_page1, mock_page2]
    mock_reader_class.return_value = mock_reader
    
    results = extract_text_from_pdf(mock_pdf_file)
    
    assert len(results) == 2
    assert results[0]["text"] == "Page 1 Content"
    assert results[0]["page"] == 1
    assert results[1]["text"] == "Page 2 Content"
    assert results[1]["page"] == 2


@patch("src.loader.PdfReader")
def test_extract_text_from_pdf_empty(mock_reader_class, mock_pdf_file):
    """Tests that a PDF with no extractable text raises DocumentProcessingError."""
    mock_reader = MagicMock()
    mock_page = MagicMock()
    mock_page.extract_text.return_value = "  " # Empty spaces
    mock_reader.pages = [mock_page]
    mock_reader_class.return_value = mock_reader
    
    with pytest.raises(DocumentProcessingError, match="No readable text could be extracted"):
        extract_text_from_pdf(mock_pdf_file)


def test_split_pages_into_chunks(sample_pages_data):
    """Verifies that text chunks are split and metadata is assigned correctly."""
    filename = "report.pdf"
    chunks = split_pages_into_chunks(sample_pages_data, filename)
    
    assert len(chunks) > 0
    # Inspect first chunk structure
    first_chunk = chunks[0]
    assert first_chunk.metadata["source"] == filename
    assert "page" in first_chunk.metadata
    assert "chunk_id" in first_chunk.metadata
    assert filename.replace(" ", "_") in first_chunk.metadata["chunk_id"]
