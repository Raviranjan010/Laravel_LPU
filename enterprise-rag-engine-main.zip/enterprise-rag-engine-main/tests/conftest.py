import pytest
import os
from pathlib import Path
from langchain_core.documents import Document

@pytest.fixture
def mock_pdf_file(tmp_path) -> Path:
    """Creates a mock PDF file path (non-existent or dummy)."""
    file_path = tmp_path / "test_doc.pdf"
    file_path.write_text("dummy pdf contents")
    return file_path


@pytest.fixture
def mock_invalid_file(tmp_path) -> Path:
    """Creates a text file path to test extension validation."""
    file_path = tmp_path / "test_doc.txt"
    file_path.write_text("this is a text file")
    return file_path


@pytest.fixture
def sample_pages_data() -> list:
    """Returns a sample page-level text extraction payload."""
    return [
        {"text": "This is page one text discussing sales figures for Q1.", "page": 1},
        {"text": "This is page two text outlining the marketing strategies for Q2.", "page": 2},
        {"text": "This is page three text summarizing the annual projections.", "page": 3}
    ]


@pytest.fixture
def sample_langchain_documents() -> list:
    """Returns a list of LangChain Document instances."""
    return [
        Document(
            page_content="This is sales analysis block.",
            metadata={"source": "report.pdf", "page": 1, "chunk_id": "report.pdf_p1_c0"}
        ),
        Document(
            page_content="This is marketing projection details.",
            metadata={"source": "report.pdf", "page": 2, "chunk_id": "report.pdf_p2_c0"}
        )
    ]
