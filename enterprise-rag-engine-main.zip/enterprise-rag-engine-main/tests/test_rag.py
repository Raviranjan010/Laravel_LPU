import pytest
import streamlit as st
from unittest.mock import MagicMock, patch
from langchain_core.messages import HumanMessage, AIMessage

from src.embeddings import get_embeddings_handler, EmbeddingError
from src.vectorstore import (
    create_or_update_vector_store,
    search_similar_chunks,
    vector_store_exists,
    VectorStoreError
)
from src.memory import (
    init_memory,
    add_user_message,
    add_assistant_message,
    get_chat_history,
    get_langchain_history
)
from src.search import perform_semantic_search
from src.config import Config

def test_embedding_missing_api_key():
    """Verifies that attempting to load embeddings without an API key raises an error."""
    # Ensure environment variables are clear for testing key checking logic
    with patch.object(Config, "get_api_key", return_value=""):
        with pytest.raises(EmbeddingError, match="Gemini API Key is missing"):
            get_embeddings_handler()


@patch("src.embeddings.GoogleGenerativeAIEmbeddings")
def test_embedding_success(mock_embeddings):
    """Verifies successful embedding client creation when API key is provided."""
    with patch.object(Config, "get_api_key", return_value="dummy_key"):
        handler = get_embeddings_handler()
        assert handler is not None
        mock_embeddings.assert_called_once_with(
            model=Config.EMBEDDING_MODEL,
            google_api_key="dummy_key"
        )


def test_memory_management():
    """Tests message insertion and retrieval logic in the session state."""
    # Initialize mock streamlit session state
    st.session_state.clear()
    init_memory()
    
    assert len(st.session_state.chat_history) == 0
    
    # Add messages
    add_user_message("Hello there")
    add_assistant_message("Hello! I am your assistant.", citations=[{"source": "doc1.pdf", "page": 1, "score": 0.95, "content": "mock text"}])
    
    history = get_chat_history()
    assert len(history) == 2
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "Hello there"
    assert history[1]["role"] == "assistant"
    assert len(history[1]["citations"]) == 1
    
    # Check LangChain formatted messages
    lc_messages = get_langchain_history()
    assert len(lc_messages) == 2
    assert isinstance(lc_messages[0], HumanMessage)
    assert isinstance(lc_messages[1], AIMessage)


@patch("src.search.vector_store_exists")
@patch("src.search.search_similar_chunks")
def test_semantic_search_mapping(mock_search_chunks, mock_store_exists):
    """Tests formatting of results in the semantic search module."""
    mock_store_exists.return_value = True
    
    # Mock search chunks return values: (Document, score)
    mock_doc = MagicMock()
    mock_doc.page_content = "sales details text content"
    mock_doc.metadata = {"source": "data.pdf", "page": 4, "chunk_id": "data.pdf_p4_c0"}
    
    mock_search_chunks.return_value = [(mock_doc, 0.88)]
    
    results = perform_semantic_search("sales figures", top_k=2, similarity_threshold=0.5, api_key="test_key")
    
    assert len(results) == 1
    assert results[0]["document_name"] == "data.pdf"
    assert results[0]["page_number"] == 4
    assert results[0]["score"] == 0.88
    assert results[0]["text_content"] == "sales details text content"
