import os
import time
from pathlib import Path
import streamlit as st

# Configure page settings BEFORE any other Streamlit commands
st.set_page_config(
    page_title="ContextFlow AI - Enterprise RAG",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

from src.config import Config
from src.logger import get_logger
from src.ui import (
    load_custom_css,
    render_header,
    render_sidebar_branding,
    render_metric_card,
    render_chat_message
)
from src.memory import (
    init_memory,
    clear_memory,
    add_user_message,
    add_assistant_message,
    get_chat_history
)
from src.loader import process_pdf_document
from src.vectorstore import (
    create_or_update_vector_store,
    clear_vector_store,
    vector_store_exists
)
from src.rag_pipeline import execute_rag_query
from src.search import perform_semantic_search
from src.summarizer import generate_document_summary
from src.analytics import get_analytics_metrics
from src.export import export_chat_as_txt, export_chat_as_markdown

logger = get_logger(__name__)

# Ensure application folders are set up
Config.initialize_directories()

# Initialize Streamlit session states
init_memory()

# Inject modern UI styles
load_custom_css()

# ----------------- SIDEBAR -----------------
with st.sidebar:
    render_sidebar_branding()
    
    # 1. API Key Input
    st.subheader("🔑 Credentials")
    env_key = Config.get_api_key()
    
    if env_key:
        st.success("API key loaded from system environment.")
        api_key = env_key
    else:
        api_key = st.text_input(
            "Enter Google Gemini API Key",
            type="password",
            placeholder="AIzaSy...",
            help="Get your key at https://aistudio.google.com/"
        )
        if not api_key:
            st.warning("Please enter your Gemini API Key to unlock retrieval pipelines.")
            
    st.markdown("---")
    
    # 2. File Upload Area
    st.subheader("📁 Document Ingestion")
    uploaded_files = st.file_uploader(
        "Upload PDF documents",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload single or multiple PDFs up to 25MB each."
    )
    
    # Ingest action button
    process_btn = st.button(
        "Ingest & Process Documents",
        use_container_width=True,
        disabled=not api_key or not uploaded_files
    )
    
    if process_btn and uploaded_files:
        with st.spinner("Processing document embeddings..."):
            try:
                all_chunks = []
                for uploaded_file in uploaded_files:
                    # Check file size validation before saving
                    file_size_mb = uploaded_file.size / (1024 * 1024)
                    if file_size_mb > Config.MAX_FILE_SIZE_MB:
                        st.error(f"'{uploaded_file.name}' is {file_size_mb:.1f}MB, which exceeds {Config.MAX_FILE_SIZE_MB}MB limit.")
                        continue
                        
                    # Save uploaded PDF to dynamic folder
                    temp_file_path = Config.UPLOAD_DIR / uploaded_file.name
                    with open(temp_file_path, "wb") as f:
                        f.write(uploaded_file.getbuffer())
                        
                    # Extract, parse pages, and partition into chunks
                    chunks = process_pdf_document(temp_file_path)
                    all_chunks.extend(chunks)
                    
                    # Store metadata into memory
                    # We can use PyPDF to read total pages for indexing metadata
                    from pypdf import PdfReader
                    reader = PdfReader(temp_file_path)
                    st.session_state.processed_files[uploaded_file.name] = {
                        "pages": len(reader.pages),
                        "size_bytes": uploaded_file.size,
                        "uploaded_at": time.time()
                    }
                    
                if all_chunks:
                    # Load / Update FAISS DB
                    create_or_update_vector_store(all_chunks, api_key=api_key)
                    st.success(f"Successfully indexed {len(all_chunks)} chunks from {len(uploaded_files)} files.")
                else:
                    st.warning("No new text chunks could be extracted from uploaded files.")
                    
            except Exception as e:
                st.error(f"Ingestion Error: {str(e)}")
                logger.error(f"Failed during file processing: {str(e)}")
                
    st.markdown("---")
    
    # 3. Model Parameters
    st.subheader("⚙️ Retrieval Config")
    top_k = st.slider(
        "Top-K Chunks to Retrieve",
        min_value=1,
        max_value=10,
        value=Config.DEFAULT_TOP_K,
        help="Number of context chunks injected into the prompt."
    )
    
    similarity_threshold = st.slider(
        "Similarity Threshold",
        min_value=0.0,
        max_value=1.0,
        value=Config.DEFAULT_SIMILARITY_THRESHOLD,
        step=0.05,
        help="Minimum matching confidence for retrieved chunks."
    )
    
    st.markdown("---")
    
    # 4. Storage reset button
    st.subheader("🗑️ Clean Storage")
    if st.button("Reset Index & Clear Chat", use_container_width=True, type="secondary"):
        try:
            clear_vector_store()
            clear_memory()
            st.session_state.processed_files = {}
            st.success("Successfully cleared vector databases and chats.")
            st.rerun()
        except Exception as e:
            st.error(f"Reset Error: {str(e)}")


# ----------------- MAIN PANEL -----------------
render_header()

# Create tabs for interactive views
tab_chat, tab_search, tab_summary, tab_analytics = st.tabs([
    "💬 AI Chat Assistant",
    "🔍 Semantic Search",
    "📄 PDF Summarizer",
    "📊 Analytics Dashboard"
])

# ----------------- TAB 1: AI CHAT ASSISTANT -----------------
with tab_chat:
    # Top controls: Export and Reset Chat buttons
    col_export, col_clear = st.columns([8, 2])
    
    with col_export:
        chat_history = get_chat_history()
        if chat_history:
            # Format and generate download payloads
            txt_chat = export_chat_as_txt(chat_history)
            md_chat = export_chat_as_markdown(chat_history)
            
            st.download_button(
                label="📥 Export Chat (.txt)",
                data=txt_chat,
                file_name="contextflow_chat_export.txt",
                mime="text/plain"
            )
            st.download_button(
                label="📥 Export Chat Markdown (.md)",
                data=md_chat,
                file_name="contextflow_chat_export.md",
                mime="text/markdown"
            )
            
    with col_clear:
        if chat_history:
            if st.button("Clear Conversation", use_container_width=True):
                clear_memory()
                st.success("Conversation cleared.")
                st.rerun()
                
    st.write("")
    
    # Chat message log container
    chat_container = st.container()
    
    with chat_container:
        # Display existing message history
        for msg in chat_history:
            render_chat_message(
                role=msg["role"],
                content=msg["content"],
                citations=msg.get("citations")
            )
            
    # Bottom chat input bar
    if not vector_store_exists():
        st.info("👋 Hello! Please upload and Ingest your PDF documents in the sidebar to start chatting.")
    else:
        user_query = st.chat_input("Ask a question about your uploaded documents...")
        
        if user_query:
            # 1. Render User Message immediately
            add_user_message(user_query)
            # Re-render to show user query
            st.rerun()
            
if vector_store_exists() and get_chat_history() and get_chat_history()[-1]["role"] == "user":
    # Get last query
    last_query = get_chat_history()[-1]["content"]
    
    # Render assistant typing layout
    with tab_chat:
        render_chat_message(role="user", content=last_query)
        
        # Assistant container
        avatar_class = "avatar-assistant"
        avatar_char = "AI"
        container_class = "chat-message-assistant"
        
        st.markdown(
            f'<div class="chat-message-container {container_class}">'
            f'  <div class="chat-avatar {avatar_class}">{avatar_char}</div>'
            f'  <div class="chat-content">',
            unsafe_allow_html=True
        )
        
        # Stream response tokens
        text_placeholder = st.empty()
        full_text = ""
        
        try:
            # Run the RAG pipeline search and retrieve token generator
            token_generator, citations = execute_rag_query(
                query=last_query,
                api_key=api_key,
                top_k=top_k,
                similarity_threshold=similarity_threshold
            )
            
            for token in token_generator:
                full_text += token
                text_placeholder.markdown(full_text + "▌")
                
            text_placeholder.markdown(full_text)
            
            # Show citations if any
            if citations:
                st.markdown('<div style="margin-top: 1rem; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 0.5rem;">', unsafe_allow_html=True)
                with st.expander("🔍 Citations & References", expanded=False):
                    for idx, cite in enumerate(citations):
                        st.markdown(
                            f"<div class='citation-box'>"
                            f"  <div class='citation-header'>"
                            f"    <span>📄 {cite['source']} (Page {cite['page']})</span>"
                            f"    <span>Match: {cite['score']:.2%}</span>"
                            f"  </div>"
                            f"  <div style='margin-top: 0.25rem; font-style: italic; color: #94a3b8; font-size: 0.85rem;'>"
                            f"    \"{cite['content']}\""
                            f"  </div>"
                            f"</div>",
                            unsafe_allow_html=True
                        )
                st.markdown('</div>', unsafe_allow_html=True)
                
            st.markdown('</div></div>', unsafe_allow_html=True)
            
            # Save generated reply in memory
            add_assistant_message(full_text, citations=citations)
            st.rerun()
            
        except Exception as e:
            error_msg = f"Failed to retrieve answer: {str(e)}"
            text_placeholder.markdown(f"⚠️ {error_msg}")
            st.markdown('</div></div>', unsafe_allow_html=True)
            add_assistant_message(f"Error: {error_msg}", citations=[])
            st.rerun()


# ----------------- TAB 2: SEMANTIC SEARCH -----------------
with tab_search:
    st.subheader("🔍 Context Extraction Engine")
    st.write("Perform semantic queries directly against the vector database to extract relevant document passages with similarity confidence levels.")
    
    search_query = st.text_input(
        "Enter semantic search keywords/phrases:",
        placeholder="Type a topic, question, or clause to search...",
        key="semantic_search_input"
    )
    
    if search_query:
        if not api_key:
            st.warning("Please supply an API key in the sidebar.")
        elif not vector_store_exists():
            st.info("No documents indexed. Ingest documents first.")
        else:
            with st.spinner("Searching document index..."):
                try:
                    search_results = perform_semantic_search(
                        query=search_query,
                        top_k=top_k,
                        similarity_threshold=similarity_threshold,
                        api_key=api_key
                    )
                    
                    if not search_results:
                        st.info("No text chunks matched your query based on the selected similarity threshold.")
                    else:
                        st.success(f"Found {len(search_results)} relevant document fragments.")
                        
                        for idx, chunk in enumerate(search_results):
                            st.markdown(
                                f"<div class='info-card'>"
                                f"  <div class='search-match-header'>"
                                f"    <strong style='color:#a855f7; font-size: 1.05rem;'>Match #{idx + 1}</strong>"
                                f"    <span style='background-color:#1e1b4b; border: 1px solid #6366f1; border-radius: 4px; padding: 2px 8px; font-size: 0.85rem; font-weight:600; color:#818cf8;'>"
                                f"      Score: {chunk['score']:.2%}"
                                f"    </span>"
                                f"  </div>"
                                f"  <div style='margin-bottom: 0.5rem; font-size: 0.9rem; color:#94a3b8;'>"
                                f"    📄 File: <strong>{chunk['document_name']}</strong> &nbsp;|&nbsp; Page: <strong>{chunk['page_number']}</strong>"
                                f"  </div>"
                                f"  <div style='font-size: 0.95rem; line-height:1.6; font-style: italic; color:#cbd5e1; background:rgba(15,23,42,0.5); padding: 10px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.02);'>"
                                f"    \"{chunk['text_content']}\""
                                f"  </div>"
                                f"</div>",
                                unsafe_allow_html=True
                            )
                            
                except Exception as e:
                    st.error(f"Search failed: {str(e)}")


# ----------------- TAB 3: DOCUMENT SUMMARIZER -----------------
with tab_summary:
    st.subheader("📄 Document Profiler & Auto-Summarizer")
    st.write("Generate comprehensive, high-quality analytical outlines, key takeaways, and core themes for individual documents.")
    
    processed_files_dict = st.session_state.get("processed_files", {})
    
    if not processed_files_dict:
        st.info("No documents uploaded. Please upload and Ingest documents in the sidebar to use the Summarizer.")
    else:
        file_options = list(processed_files_dict.keys())
        selected_doc = st.selectbox(
            "Select document to summarize:",
            options=file_options,
            help="Outlining large files might take a few moments depending on length."
        )
        
        sum_btn = st.button("Generate Outlines & Summaries", type="primary")
        
        if sum_btn and selected_doc:
            doc_path = Config.UPLOAD_DIR / selected_doc
            
            if not doc_path.exists():
                st.error("Select document file path doesn't exist on disk.")
            else:
                with st.spinner("Generating document analysis..."):
                    try:
                        summary_result = generate_document_summary(doc_path, api_key=api_key)
                        st.success("Summary generated successfully!")
                        st.markdown("---")
                        st.markdown(summary_result)
                        
                        # Add a download summary button
                        st.download_button(
                            label="📥 Download Summary (.md)",
                            data=summary_result,
                            file_name=f"{selected_doc}_summary.md",
                            mime="text/markdown"
                        )
                    except Exception as e:
                        st.error(f"Summarization failed: {str(e)}")


# ----------------- TAB 4: ANALYTICS DASHBOARD -----------------
with tab_analytics:
    st.subheader("📊 Document & Performance Metrics")
    st.write("Monitor system storage size, text parsing densities, vector embedding weights, and chatbot engagement lengths.")
    
    analytics = get_analytics_metrics(api_key=api_key)
    
    # Render Metric Cards in custom grid
    metrics_grid_html = (
        f'<div class="metric-container">'
        f'  {render_metric_card("Ingested Docs", analytics["total_documents"])}'
        f'  {render_metric_card("Total Pages", analytics["total_pages"])}'
        f'  {render_metric_card("FAISS Chunks", analytics["total_chunks"])}'
        f'  {render_metric_card("Embeddings Count", analytics["total_embeddings"])}'
        f'  {render_metric_card("Session Duration", analytics["session_duration_str"])}'
        f'  {render_metric_card("Session Messages", analytics["message_count"])}'
        f'</div>'
    )
    st.markdown(metrics_grid_html, unsafe_allow_html=True)
    
    st.write("")
    
    # Ingested Files Listing table
    st.subheader("📁 Ingested Files Inventory")
    files_list = analytics["uploaded_files_list"]
    
    if not files_list:
        st.info("No file inventory logged. Ingest documents to populate the dashboard table.")
    else:
        import datetime
        
        # Display as styled table
        # We can construct markdown table
        md_table = (
            "| Document Filename | Size (MB) | Total Pages | Upload Timestamp |\n"
            "| :--- | :---: | :---: | :--- |\n"
        )
        
        for file_info in files_list:
            formatted_time = datetime.datetime.fromtimestamp(file_info["uploaded_at"]).strftime("%Y-%m-%d %H:%M:%S")
            md_table += f"| **{file_info['name']}** | {file_info['size_mb']:.2f} MB | {file_info['pages']} | {formatted_time} |\n"
            
        st.markdown(md_table)
