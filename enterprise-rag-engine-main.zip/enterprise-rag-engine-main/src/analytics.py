import time
import streamlit as st
from typing import Dict, Any, List
from src.config import Config
from src.vectorstore import vector_store_exists, load_vector_store
from src.memory import get_session_duration
from src.logger import get_logger

logger = get_logger(__name__)

def get_analytics_metrics(api_key: str = None) -> Dict[str, Any]:
    """
    Aggregates metrics for the Analytics Dashboard.
    
    Metrics returned:
        - total_documents: Number of uploaded PDF documents.
        - total_pages: Total number of pages across all PDFs.
        - total_chunks: Total vector chunks created in FAISS.
        - total_embeddings: Number of generated embedding vectors (equal to total_chunks).
        - session_duration_str: Formatted string of active session duration.
        - upload_timestamp: When the last file was uploaded (or current time if none).
        - message_count: Total messages exchanged in the chat session.
        - uploaded_files_list: List of metadata dictionaries about each file.
    """
    metrics = {
        "total_documents": 0,
        "total_pages": 0,
        "total_chunks": 0,
        "total_embeddings": 0,
        "session_duration_str": "0s",
        "message_count": 0,
        "uploaded_files_list": []
    }
    
    try:
        # 1. Fetch file list and page counts from session state
        processed_files = st.session_state.get("processed_files", {})
        metrics["total_documents"] = len(processed_files)
        
        total_pages = 0
        files_list = []
        for filename, info in processed_files.items():
            total_pages += info.get("pages", 0)
            files_list.append({
                "name": filename,
                "size_mb": info.get("size_bytes", 0) / (1024 * 1024),
                "pages": info.get("pages", 0),
                "uploaded_at": info.get("uploaded_at", time.time())
            })
        
        metrics["total_pages"] = total_pages
        metrics["uploaded_files_list"] = files_list
        
        # 2. Count chunks in FAISS database
        if vector_store_exists():
            try:
                vector_db = load_vector_store(api_key)
                # In FAISS, we can fetch all document IDs or look at the index size
                # index.ntotal gives the total number of vectors (chunks)
                total_chunks = vector_db.index.ntotal
                metrics["total_chunks"] = total_chunks
                metrics["total_embeddings"] = total_chunks
            except Exception as store_err:
                logger.error(f"Error reading FAISS index size for analytics: {str(store_err)}")
                metrics["total_chunks"] = 0
                metrics["total_embeddings"] = 0
                
        # 3. Session time formatting
        duration_seconds = get_session_duration()
        metrics["session_duration_str"] = format_duration(duration_seconds)
        
        # 4. Message count
        chat_history = st.session_state.get("chat_history", [])
        metrics["message_count"] = len(chat_history)
        
        return metrics
        
    except Exception as e:
        logger.error(f"Failed to compile analytics: {str(e)}")
        return metrics


def format_duration(seconds: float) -> str:
    """Formats float duration seconds into readable HH:MM:SS format."""
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        minutes = seconds // 60
        secs = seconds % 60
        return f"{minutes}m {secs}s"
    else:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        return f"{hours}h {minutes}m {secs}s"
