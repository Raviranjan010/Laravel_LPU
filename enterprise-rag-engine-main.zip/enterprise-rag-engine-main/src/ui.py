import streamlit as st
from typing import List, Dict, Any
from pathlib import Path
from src.config import Config
from src.logger import get_logger

logger = get_logger(__name__)

def load_custom_css() -> None:
    """Reads assets/styles.css and injects it into the Streamlit session."""
    css_path = Config.BASE_DIR / "assets" / "styles.css"
    try:
        if css_path.exists():
            with open(css_path, "r", encoding="utf-8") as f:
                css_data = f.read()
            st.markdown(f"<style>{css_data}</style>", unsafe_allow_html=True)
            logger.debug("Successfully injected custom CSS stylesheet.")
        else:
            logger.warning(f"CSS stylesheet not found at expected location: {css_path}")
    except Exception as e:
        logger.error(f"Error loading CSS stylesheet: {str(e)}")


def render_header() -> None:
    """Renders the custom gradient header banner."""
    header_html = (
        '<div class="header-container">'
        '  <div class="header-title">ContextFlow AI</div>'
        '  <div class="header-subtitle">Enterprise RAG Document Assistant</div>'
        '</div>'
    )
    st.markdown(header_html, unsafe_allow_html=True)


def render_sidebar_branding() -> None:
    """Renders the custom sidebar brand name and logo area."""
    logo_html = (
        '<div class="sidebar-logo">'
        '  <h2>CF Flow</h2>'
        '  <span style="color: #64748b; font-size: 0.8rem; font-weight: 500;">ENTERPRISE EDITION</span>'
        '</div>'
    )
    st.markdown(logo_html, unsafe_allow_html=True)


def render_metric_card(label: str, value: Any) -> str:
    """Returns the HTML structure for a single custom glassmorphism metric card."""
    return (
        f'<div class="metric-card">'
        f'  <div class="metric-label">{label}</div>'
        f'  <div class="metric-value">{value}</div>'
        f'</div>'
    )


def render_chat_message(role: str, content: str, citations: List[Dict[str, Any]] = None) -> None:
    """
    Renders user/assistant messages with customized HTML bubbles,
    supporting profile avatars, Markdown formatting, and citations accordions.
    """
    avatar_class = "avatar-user" if role == "user" else "avatar-assistant"
    avatar_char = "U" if role == "user" else "AI"
    container_class = "chat-message-user" if role == "user" else "chat-message-assistant"
    
    # Custom rendered message block
    msg_html = (
        f'<div class="chat-message-container {container_class}">'
        f'  <div class="chat-avatar {avatar_class}">{avatar_char}</div>'
        f'  <div class="chat-content">'
    )
    
    # Let Streamlit handle markdown rendering inside our layout container to prevent formatting loss
    st.markdown(msg_html, unsafe_allow_html=True)
    
    # Use native streamlit markdown for the content inside, so tables, code blocks, lists render properly
    st.markdown(content)
    
    # If assistant message contains citations, render them at the bottom
    if role == "assistant" and citations:
        st.markdown('<div style="margin-top: 1rem; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 0.5rem;">', unsafe_allow_html=True)
        with st.expander("🔍 Citations & References", expanded=False):
            for idx, cite in enumerate(citations):
                st.markdown(
                    f"<div class='citation-box'>"
                    f"  <div class='citation-header'>"
                    f"    <span>📄 {cite['source']} (Page {cite['page']})</span>"
                    f"    <span>Match: {cite['score']:.2%}</span>"
                    f"  </div>"
                    f"  <div style='margin-top: 0.25rem; font-style: italic; color: #94a3b8; font-size: 0.85rem;'>"
                    f"    \"{cite['content']}\""
                    f"  </div>"
                    f"</div>",
                    unsafe_allow_html=True
                )
        st.markdown('</div>', unsafe_allow_html=True)
        
    st.markdown('</div></div>', unsafe_allow_html=True)
