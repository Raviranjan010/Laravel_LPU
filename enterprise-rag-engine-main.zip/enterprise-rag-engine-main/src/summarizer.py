from pathlib import Path
from langchain_core.messages import SystemMessage, HumanMessage
from src.config import Config
from src.loader import extract_text_from_pdf
from src.rag_pipeline import get_llm_client
from src.logger import get_logger

logger = get_logger(__name__)

class SummarizerError(Exception):
    """Custom exception raised for document summarization failures."""
    pass


def generate_document_summary(
    file_path: Path,
    api_key: str = None
) -> str:
    """
    Reads text content from the file path, and generates a structured summary using Gemini.
    Handles large documents by summarizing up to a maximum length limit to fit
    within rate limits and processing times.
    """
    try:
        # Extract text page by page
        logger.info(f"Extracting text to summarize: {file_path.name}")
        pages_data = extract_text_from_pdf(file_path)
        
        # Combine pages text
        full_text = ""
        for page in pages_data:
            full_text += f"\n--- Page {page['page']} ---\n"
            full_text += page["text"]
            
        text_length = len(full_text)
        logger.info(f"Extracted {text_length} characters for summarization.")
        
        # Max character limit to avoid Gemini free tier token timeouts
        # 300,000 characters is ~75,000 tokens
        max_chars = 300000
        if text_length > max_chars:
            logger.warning(f"Document text length ({text_length}) exceeds {max_chars} chars. Truncating for summary...")
            full_text = full_text[:max_chars] + "\n\n[Content truncated for summarization limits...]"
            
        # Initialize Gemini LLM
        llm = get_llm_client(api_key=api_key, temperature=0.3)
        
        system_instruction = (
            "You are an expert technical editor and business analyst.\n"
            "Your task is to analyze the provided document text and write a professional, structured, "
            "comprehensive summary in Markdown.\n\n"
            "You MUST follow this exact structure:\n"
            "# Document Analysis & Summary: <Insert Document Name>\n\n"
            "## 1. Executive Summary\n"
            "[Provide a concise, high-level summary of the document's main objective, key findings, and value proposition in 2-3 detailed paragraphs.]\n\n"
            "## 2. Comprehensive Full Summary\n"
            "[Summarize the entire document's core content, logical sections, and main details exhaustively. Retain key figures, dates, and conclusions.]\n\n"
            "## 3. Key Takeaways\n"
            "- **Takeaway 1**: [Description]\n"
            "- **Takeaway 2**: [Description]\n"
            "- **Takeaway 3**: [Description]\n"
            "[Add more key takeaways as required by the text complexity, minimum 3, maximum 6]\n\n"
            "## 4. Important Topics & Themes\n"
            "- **Topic/Theme Name**: [Explain how this topic is explored and resolved in the text]\n"
            "[Add more important topics as required, minimum 2, maximum 5]\n\n"
            "Ensure the output uses professional business-grade language. Avoid filler phrases."
        )
        
        user_prompt = (
            f"Here is the text extracted from the document '{file_path.name}':\n\n"
            f"--- START DOCUMENT TEXT ---\n"
            f"{full_text}\n"
            f"--- END DOCUMENT TEXT ---\n\n"
            f"Please generate the analysis and summary according to your instructions."
        )
        
        messages = [
            SystemMessage(content=system_instruction),
            HumanMessage(content=user_prompt)
        ]
        
        logger.info(f"Invoking Gemini to summarize {file_path.name}...")
        response = llm.invoke(messages)
        
        logger.info(f"Successfully generated summary for {file_path.name}.")
        return response.content
        
    except Exception as e:
        logger.error(f"Error during summarization of {file_path.name}: {str(e)}")
        raise SummarizerError(f"Summarization failed: {str(e)}")
