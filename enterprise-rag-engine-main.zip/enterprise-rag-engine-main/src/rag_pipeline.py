from typing import Generator, List, Dict, Any, Tuple
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

from src.config import Config
from src.vectorstore import search_similar_chunks, vector_store_exists
from src.memory import get_langchain_history
from src.logger import get_logger

logger = get_logger(__name__)

class RAGPipelineError(Exception):
    """Custom exception raised for RAG compilation and inference failures."""
    pass


def get_llm_client(api_key: str = None, temperature: float = 0.2) -> ChatGoogleGenerativeAI:
    """
    Initializes and returns the LangChain Gemini LLM client.
    """
    resolved_key = Config.get_api_key(api_key)
    
    if not resolved_key:
        logger.error("Attempted to initialize LLM client without a Gemini API Key.")
        raise RAGPipelineError(
            "Gemini API Key is missing. Please add it to your environment variables or sidebar input."
        )
        
    try:
        logger.info(f"Initializing ChatGoogleGenerativeAI with model: {Config.LLM_MODEL}...")
        llm = ChatGoogleGenerativeAI(
            model=Config.LLM_MODEL,
            google_api_key=resolved_key,
            temperature=temperature,
            streaming=True
        )
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize ChatGoogleGenerativeAI: {str(e)}")
        raise RAGPipelineError(f"Error initializing Gemini LLM client: {str(e)}")


def build_system_prompt(contexts: List[Tuple[Any, float]]) -> SystemMessage:
    """
    Constructs the RAG system prompt injected with retrieved context blocks.
    Strictly tells the LLM to only answer based on the context and avoid hallucinations.
    """
    context_str = ""
    for idx, (doc, score) in enumerate(contexts):
        doc_name = doc.metadata.get("source", "Unknown Document")
        page_num = doc.metadata.get("page", "Unknown Page")
        context_str += f"\n--- CONTEXT CHUNK {idx + 1} (Source: {doc_name}, Page: {page_num}, Similarity: {score:.2%}) ---\n"
        context_str += doc.page_content + "\n"
        
    if not context_str:
        context_str = "No relevant context found. Inform the user you couldn't find relevant content in their uploaded documents."
        
    system_instruction = (
        "You are ContextFlow AI, a highly precise, helpful, and objective Enterprise RAG Assistant.\n"
        "Your task is to answer the User's question using ONLY the provided Context Chunks below.\n\n"
        "CRITICAL RULES:\n"
        "1. Answer the question exhaustively and accurately based ONLY on the provided context.\n"
        "2. If the context does not contain the answer, say: 'I cannot find the answer in the uploaded documents. "
        "Could you please rephrase or specify which part of the document you are referring to?' "
        "Do NOT use external knowledge or make up facts.\n"
        "3. Keep your tone professional, structured, and informative. Use markdown lists and headings where appropriate.\n"
        "4. DO NOT mention chunk IDs or similarity percentages directly in your body text unless specifically asked, "
        "but reference the facts accurately.\n\n"
        f"--- CONTEXT START ---\n{context_str}\n--- CONTEXT END ---"
    )
    
    return SystemMessage(content=system_instruction)


def execute_rag_query(
    query: str,
    api_key: str = None,
    top_k: int = None,
    similarity_threshold: float = None
) -> Tuple[Generator[str, None, None], List[Dict[str, Any]]]:
    """
    Performs retrieval, builds the prompt sequence (System context, memory history, and latest user query),
    and returns:
    1. A token generator that streams the response.
    2. A list of citations (retrieved context chunks).
    
    Raises RAGPipelineError if vector store doesn't exist.
    """
    if not vector_store_exists():
        raise RAGPipelineError("Vector store does not exist. Please upload PDF documents first.")
        
    try:
        # 1. Retrieve similar chunks
        retrieved_chunks = search_similar_chunks(
            query=query,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            api_key=api_key
        )
        
        # 2. Formulate citations list
        citations = []
        for doc, score in retrieved_chunks:
            citations.append({
                "source": doc.metadata.get("source", "Unknown Document"),
                "page": doc.metadata.get("page", "N/A"),
                "chunk_id": doc.metadata.get("chunk_id", "N/A"),
                "score": score,
                "content": doc.page_content
            })
            
        # 3. Build message list
        system_message = build_system_prompt(retrieved_chunks)
        
        # Retrieve recent history (up to last 10 messages)
        history_messages = get_langchain_history(limit=10)
        
        # Latest query
        user_message = HumanMessage(content=query)
        
        # Combine messages
        prompt_messages = [system_message] + history_messages + [user_message]
        
        # 4. Initialize LLM and stream response
        llm = get_llm_client(api_key=api_key)
        
        def token_generator() -> Generator[str, None, None]:
            try:
                for chunk in llm.stream(prompt_messages):
                    # In langchain_google_genai, chunk is an BaseMessageChunk
                    # extract the content string
                    content = chunk.content
                    if content:
                        yield content
            except Exception as e:
                logger.error(f"Stream generation error: {str(e)}")
                yield f"\n\n[Error occurred during response generation: {str(e)}]"
                
        return token_generator(), citations
        
    except Exception as e:
        if isinstance(e, RAGPipelineError):
            raise e
        logger.error(f"Failed to execute RAG query: {str(e)}")
        raise RAGPipelineError(f"RAG query execution failed: {str(e)}")
