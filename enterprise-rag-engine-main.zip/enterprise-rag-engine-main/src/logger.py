import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from src.config import Config

# Initialize directory structures first to ensure logs directory exists
Config.initialize_directories()

log_file_path = Config.LOG_DIR / "app.log"

# Setup formatter
log_formatter = logging.Formatter(
    "[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# Stream handler for stdout/stderr
stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setFormatter(log_formatter)
stream_handler.setLevel(logging.INFO)

# Rotating File Handler (5MB file size limit, keeps up to 3 backups)
file_handler = RotatingFileHandler(
    log_file_path,
    maxBytes=5 * 1024 * 1024,
    backupCount=3,
    encoding="utf-8"
)
file_handler.setFormatter(log_formatter)
file_handler.setLevel(logging.DEBUG)

# Configure Root Logger
root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)

# Remove any existing handlers to prevent duplicate logs
if root_logger.hasHandlers():
    root_logger.handlers.clear()

root_logger.addHandler(stream_handler)
root_logger.addHandler(file_handler)

def get_logger(module_name: str) -> logging.Logger:
    """Returns a logger instance specifically named after the requesting module."""
    return logging.getLogger(module_name)
