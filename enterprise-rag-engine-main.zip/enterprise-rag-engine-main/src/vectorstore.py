import os
import shutil
from pathlib import Path
from typing import List, Tuple, Optional
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from src.config import Config
from src.embeddings import get_embeddings_handler
from src.logger import get_logger

logger = get_logger(__name__)

class VectorStoreError(Exception):
    """Custom exception raised for FAISS operation errors."""
    pass


def get_vector_store_path() -> Path:
    """Returns the absolute path to the local FAISS index folder."""
    return Config.VECTOR_STORE_DIR / "faiss_index"


def vector_store_exists() -> bool:
    """Checks if a FAISS index already exists on disk."""
    path = get_vector_store_path()
    return (path / "index.faiss").exists() and (path / "index.pkl").exists()


def create_or_update_vector_store(documents: List[Document], api_key: str = None) -> FAISS:
    """
    Creates a new FAISS vector store or updates the existing one with new documents.
    Saves the updated index to disk.
    """
    if not documents:
        logger.warning("No documents provided to create or update vector store.")
        if vector_store_exists():
            return load_vector_store(api_key)
        raise VectorStoreError("Cannot create a vector store from an empty list of documents.")

    try:
        embeddings = get_embeddings_handler(api_key)
        store_path = get_vector_store_path()
        
        if vector_store_exists():
            logger.info("Existing vector store found. Loading and merging new documents...")
            vector_db = FAISS.load_local(
                folder_path=str(store_path),
                embeddings=embeddings,
                allow_dangerous_deserialization=True  # Required for local FAISS loading
            )
            vector_db.add_documents(documents)
            logger.info(f"Added {len(documents)} documents to existing vector store.")
        else:
            logger.info("No vector store found. Creating new FAISS index...")
            vector_db = FAISS.from_documents(documents, embeddings)
            logger.info(f"Created new vector store with {len(documents)} documents.")
            
        # Persist index to disk
        vector_db.save_local(str(store_path))
        logger.info(f"Vector store saved to {store_path}.")
        return vector_db
        
    except Exception as e:
        logger.error(f"Error creating/updating vector store: {str(e)}")
        raise VectorStoreError(f"Vector store operation failed: {str(e)}")


def load_vector_store(api_key: str = None) -> FAISS:
    """Loads the FAISS vector store from disk."""
    if not vector_store_exists():
        raise VectorStoreError("Vector store does not exist on disk. Please upload files first.")
        
    try:
        embeddings = get_embeddings_handler(api_key)
        store_path = get_vector_store_path()
        logger.info("Loading vector store from disk...")
        vector_db = FAISS.load_local(
            folder_path=str(store_path),
            embeddings=embeddings,
            allow_dangerous_deserialization=True
        )
        return vector_db
    except Exception as e:
        logger.error(f"Failed to load vector store: {str(e)}")
        raise VectorStoreError(f"Error loading vector store: {str(e)}")


def clear_vector_store() -> None:
    """Clears all stored vector index files and dynamic directories."""
    store_path = get_vector_store_path()
    try:
        if store_path.exists():
            shutil.rmtree(store_path)
            logger.info("Successfully deleted local FAISS vector store directory.")
            
        # Clean uploads folder as well
        if Config.UPLOAD_DIR.exists():
            for filename in os.listdir(Config.UPLOAD_DIR):
                file_path = Config.UPLOAD_DIR / filename
                if file_path.is_file():
                    os.unlink(file_path)
            logger.info("Cleaned uploaded PDFs from temporary storage.")
    except Exception as e:
        logger.error(f"Error clearing vector store resources: {str(e)}")
        raise VectorStoreError(f"Failed to clear storage files: {str(e)}")


def search_similar_chunks(
    query: str,
    top_k: int = None,
    similarity_threshold: float = None,
    api_key: str = None
) -> List[Tuple[Document, float]]:
    """
    Performs similarity search on FAISS vector store.
    Normalizes distance scores into similarity scores:
    Google Gemini Embeddings are L2 normalized, so similarity_score = 1 - (L2_distance / 2).
    Filters results using similarity_threshold.
    
    Returns list of tuples: (Document, similarity_score)
    """
    if not vector_store_exists():
        logger.warning("Search requested but FAISS vector store does not exist.")
        return []
        
    top_k = top_k or Config.DEFAULT_TOP_K
    # Let's read the threshold from config if not provided, or default to 0.0 to return everything
    threshold = similarity_threshold if similarity_threshold is not None else Config.DEFAULT_SIMILARITY_THRESHOLD
    
    try:
        vector_db = load_vector_store(api_key)
        
        # FAISS returns (doc, L2_distance)
        raw_results = vector_db.similarity_search_with_score(query, k=top_k)
        
        filtered_results = []
        for doc, distance in raw_results:
            # Convert L2 distance to normalized similarity score (range 0 to 1)
            # distance is d^2, where d is the distance. 
            # Since Gemini embeddings are unit vectors, 0 <= distance <= 4.
            # Normalization: similarity = 1 - (distance / 4) or 1 - (distance / 2) depending on if it's cosine dist.
            # Typically for unit-normed, cosine distance is distance / 2.
            # Let's map it safely: similarity = max(0.0, min(1.0, 1.0 - (distance / 2.0)))
            similarity = max(0.0, min(1.0, 1.0 - (distance / 2.0)))
            
            if similarity >= threshold:
                filtered_results.append((doc, similarity))
                
        logger.info(f"Query: '{query}' returned {len(filtered_results)} results above threshold {threshold}.")
        return filtered_results
        
    except Exception as e:
        logger.error(f"Error performing similarity search: {str(e)}")
        raise VectorStoreError(f"Search failed: {str(e)}")
