from langchain_google_genai import GoogleGenerativeAIEmbeddings
from src.config import Config
from src.logger import get_logger

logger = get_logger(__name__)

class EmbeddingError(Exception):
    """Custom exception raised for errors related to embedding creation and validation."""
    pass


def get_embeddings_handler(api_key: str = None) -> GoogleGenerativeAIEmbeddings:
    """
    Initializes and returns the GoogleGenerativeAIEmbeddings client.
    
    Args:
        api_key (str, optional): The Gemini API key. If not provided, it will search the config settings.
        
    Returns:
        GoogleGenerativeAIEmbeddings: The embedding client.
        
    Raises:
        EmbeddingError: If the API key is missing.
    """
    resolved_key = Config.get_api_key(api_key)
    
    if not resolved_key:
        logger.error("Attempted to initialize embeddings without a Gemini API Key.")
        raise EmbeddingError(
            "Gemini API Key is missing. Please add it to your environment variables or sidebar input."
        )
        
    try:
        logger.info(f"Initializing GoogleGenerativeAIEmbeddings with model: {Config.EMBEDDING_MODEL}...")
        embeddings = GoogleGenerativeAIEmbeddings(
            model=Config.EMBEDDING_MODEL,
            google_api_key=resolved_key
        )
        return embeddings
    except Exception as e:
        logger.error(f"Failed to initialize embeddings: {str(e)}")
        raise EmbeddingError(f"Error initializing Google Gemini embeddings: {str(e)}")
