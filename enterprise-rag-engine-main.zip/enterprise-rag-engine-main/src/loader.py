import os
import uuid
from typing import List, Dict, Any
from pathlib import Path
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from src.config import Config
from src.logger import get_logger

logger = get_logger(__name__)

class DocumentProcessingError(Exception):
    """Custom exception raised for errors encountered during PDF loading and splitting."""
    pass


def validate_pdf(file_path: Path) -> None:
    """
    Validates a PDF file.
    Checks for existence, extension, size limits, and basic readability.
    Raises DocumentProcessingError if invalid.
    """
    if not file_path.exists():
        raise DocumentProcessingError(f"File not found: {file_path}")
    
    if file_path.suffix.lower() not in Config.ALLOWED_EXTENSIONS:
        raise DocumentProcessingError(
            f"Unsupported file type '{file_path.suffix}'. Only PDF files are supported."
        )
    
    file_size_mb = file_path.stat().st_size / (1024 * 1024)
    if file_size_mb > Config.MAX_FILE_SIZE_MB:
        raise DocumentProcessingError(
            f"File size ({file_size_mb:.2f}MB) exceeds the maximum allowed limit of {Config.MAX_FILE_SIZE_MB}MB."
        )


def extract_text_from_pdf(file_path: Path) -> List[Dict[str, Any]]:
    """
    Reads a PDF file and extracts text page-by-page.
    Returns a list of dicts: [{'text': page_text, 'page': page_num}]
    """
    validate_pdf(file_path)
    
    pages_data = []
    try:
        reader = PdfReader(file_path)
        total_pages = len(reader.pages)
        
        if total_pages == 0:
            raise DocumentProcessingError(f"The PDF file '{file_path.name}' contains no pages.")
            
        logger.info(f"Extracting text from '{file_path.name}' ({total_pages} pages)...")
        
        extracted_any_text = False
        for idx, page in enumerate(reader.pages):
            page_num = idx + 1
            text = page.extract_text() or ""
            text = text.strip()
            
            if text:
                extracted_any_text = True
            
            pages_data.append({
                "text": text,
                "page": page_num
            })
            
        if not extracted_any_text:
            raise DocumentProcessingError(
                f"No readable text could be extracted from '{file_path.name}'. "
                "The file may contain only scanned images or be protected."
            )
            
        logger.info(f"Successfully extracted text from '{file_path.name}'.")
        return pages_data
        
    except Exception as e:
        if isinstance(e, DocumentProcessingError):
            raise e
        logger.error(f"Failed to parse PDF '{file_path}': {str(e)}")
        raise DocumentProcessingError(f"Error parsing PDF file: {str(e)}")


def split_pages_into_chunks(pages_data: List[Dict[str, Any]], filename: str) -> List[Document]:
    """
    Splits page-level text into overlapping chunks using RecursiveCharacterTextSplitter.
    Attaches critical metadata: filename, page number, and a deterministic chunk_id.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=Config.CHUNK_SIZE,
        chunk_overlap=Config.CHUNK_OVERLAP,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    
    chunks = []
    
    for page_entry in pages_data:
        text = page_entry["text"]
        page_num = page_entry["page"]
        
        if not text:
            continue
            
        # Split text on this specific page
        page_chunks = splitter.split_text(text)
        
        for chunk_idx, chunk_text in enumerate(page_chunks):
            # Formulate a stable, unique chunk identifier
            # e.g., "report.pdf_page_5_chunk_0"
            clean_filename = filename.replace(" ", "_")
            chunk_id = f"{clean_filename}_p{page_num}_c{chunk_idx}"
            
            metadata = {
                "source": filename,
                "page": page_num,
                "chunk_id": chunk_id
            }
            
            chunks.append(Document(page_content=chunk_text, metadata=metadata))
            
    logger.info(f"Split document '{filename}' into {len(chunks)} chunks.")
    return chunks


def process_pdf_document(file_path: Path) -> List[Document]:
    """
    High-level function to validate, extract text, and chunk a PDF document.
    """
    try:
        pages_data = extract_text_from_pdf(file_path)
        chunks = split_pages_into_chunks(pages_data, file_path.name)
        return chunks
    except Exception as e:
        logger.error(f"Error processing document {file_path.name}: {str(e)}")
        raise
