import datetime
from typing import List, Dict, Any
from src.logger import get_logger

logger = get_logger(__name__)

def export_chat_as_txt(history: List[Dict[str, Any]]) -> str:
    """
    Formats the session chat history list into a raw plain text string.
    """
    if not history:
        return "No conversation history to export."
        
    timestamp_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    txt_content = (
        "==================================================\n"
        "           CONTEXTFLOW AI CHAT EXPORT             \n"
        f"Export Date: {timestamp_now}\n"
        "==================================================\n\n"
    )
    
    for idx, msg in enumerate(history):
        role = msg["role"].upper()
        content = msg["content"]
        time_str = datetime.datetime.fromtimestamp(msg.get("timestamp", datetime.datetime.now().timestamp())).strftime("%Y-%m-%d %H:%M:%S")
        
        txt_content += f"[{time_str}] {role}:\n"
        txt_content += f"{content}\n"
        
        # Add citations if present and role is assistant
        if role == "ASSISTANT" and msg.get("citations"):
            txt_content += "\nSources Cited:\n"
            for cite_idx, cite in enumerate(msg["citations"]):
                txt_content += f"  ({cite_idx + 1}) File: {cite['source']}, Page: {cite['page']} (Similarity: {cite['score']:.2%})\n"
                
        txt_content += "\n" + "-" * 50 + "\n\n"
        
    logger.info("Successfully exported chat history as plain text.")
    return txt_content


def export_chat_as_markdown(history: List[Dict[str, Any]]) -> str:
    """
    Formats the session chat history list into a structured Markdown document.
    """
    if not history:
        return "# ContextFlow AI Chat Export\nNo conversation history to export."
        
    timestamp_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    md_content = (
        f"# ContextFlow AI Chat Export\n"
        f"*Export Date: {timestamp_now}*\n\n"
        f"---\n\n"
    )
    
    for msg in history:
        role = msg["role"]
        content = msg["content"]
        time_str = datetime.datetime.fromtimestamp(msg.get("timestamp", datetime.datetime.now().timestamp())).strftime("%Y-%m-%d %H:%M:%S")
        
        if role == "user":
            md_content += f"### 👤 User *({time_str})*\n\n"
            md_content += f"{content}\n\n"
        else:
            md_content += f"### 🤖 Assistant *({time_str})*\n\n"
            md_content += f"{content}\n\n"
            
            # Add citations block
            citations = msg.get("citations", [])
            if citations:
                md_content += "**Sources Cited:**\n"
                for cite in citations:
                    md_content += f"- 📄 **{cite['source']}** — Page {cite['page']} (Confidence: `{cite['score']:.2%}`)\n"
                md_content += "\n"
                
        md_content += "---\n\n"
        
    logger.info("Successfully exported chat history as Markdown.")
    return md_content
