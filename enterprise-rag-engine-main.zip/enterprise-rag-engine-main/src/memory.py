import time
import streamlit as st
from typing import List, Dict, Any
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage

from src.logger import get_logger

logger = get_logger(__name__)

def init_memory() -> None:
    """Initializes necessary Streamlit session state objects if they don't exist."""
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
        logger.info("Initialized chat_history in session state.")
        
    if "session_start_time" not in st.session_state:
        st.session_state.session_start_time = time.time()
        logger.info("Initialized session_start_time in session state.")
        
    if "processed_files" not in st.session_state:
        # Dictionary format: {filename: {'pages': page_count, 'size_bytes': size, 'uploaded_at': ts}}
        st.session_state.processed_files = {}
        logger.info("Initialized processed_files tracker in session state.")


def clear_memory() -> None:
    """Resets chat history in the current session state."""
    st.session_state.chat_history = []
    logger.info("Cleared chat history in session state.")


def add_user_message(content: str) -> None:
    """Appends a new user message to session state history."""
    init_memory()
    st.session_state.chat_history.append({
        "role": "user",
        "content": content,
        "timestamp": time.time()
    })
    logger.debug(f"Added user message: '{content[:50]}...'")


def add_assistant_message(content: str, citations: List[Dict[str, Any]] = None) -> None:
    """Appends a new assistant message along with its citations to session state history."""
    init_memory()
    st.session_state.chat_history.append({
        "role": "assistant",
        "content": content,
        "citations": citations or [],
        "timestamp": time.time()
    })
    logger.debug(f"Added assistant message: '{content[:50]}...' with {len(citations or [])} citations.")


def get_chat_history() -> List[Dict[str, Any]]:
    """Returns the list of chat messages stored in session state."""
    init_memory()
    return st.session_state.chat_history


def get_langchain_history(limit: int = 10) -> List[BaseMessage]:
    """
    Converts the latest chat history messages into LangChain base messages (HumanMessage/AIMessage)
    for injecting into the system prompt as conversation context.
    """
    init_memory()
    history = st.session_state.chat_history
    
    # Grab last `limit` messages
    recent_history = history[-limit:] if len(history) > limit else history
    
    messages = []
    for msg in recent_history:
        if msg["role"] == "user":
            messages.append(HumanMessage(content=msg["content"]))
        elif msg["role"] == "assistant":
            messages.append(AIMessage(content=msg["content"]))
            
    return messages


def get_session_duration() -> float:
    """Returns total duration of current session in seconds."""
    init_memory()
    return time.time() - st.session_state.session_start_time
