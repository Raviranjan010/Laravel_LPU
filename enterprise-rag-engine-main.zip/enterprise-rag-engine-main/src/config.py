import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

class Config:
    # Root and storage paths
    BASE_DIR = Path(__file__).resolve().parent.parent
    UPLOAD_DIR = BASE_DIR / "uploads"
    VECTOR_STORE_DIR = BASE_DIR / "vector_store"
    LOG_DIR = BASE_DIR / "logs"

    # Default model configuration
    # text-embedding-004 is recommended for Gemini Embeddings
    EMBEDDING_MODEL = "models/text-embedding-004"
    # gemini-2.5-flash is the recommended free stack model
    LLM_MODEL = "gemini-2.5-flash"

    # Text Chunking Settings
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200

    # Security constraints
    MAX_FILE_SIZE_MB = 25  # Support large PDFs up to 25MB
    ALLOWED_EXTENSIONS = {".pdf"}

    # Default Top-K and retrieval parameters
    DEFAULT_TOP_K = 4
    DEFAULT_SIMILARITY_THRESHOLD = 0.4  # Similarity score threshold (normalized distance / score)

    @classmethod
    def initialize_directories(cls):
        """Creates the necessary directories for the application if they do not exist."""
        cls.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        cls.VECTOR_STORE_DIR.mkdir(parents=True, exist_ok=True)
        cls.LOG_DIR.mkdir(parents=True, exist_ok=True)

    @classmethod
    def get_api_key(cls, session_key: str = None) -> str:
        """
        Retrieves the Gemini API Key.
        Checks Streamlit session state first (if session_key provided),
        then environment variables: GEMINI_API_KEY, and then GOOGLE_API_KEY.
        """
        if session_key:
            return session_key
        
        # Check GEMINI_API_KEY first
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            # Fallback to standard GOOGLE_API_KEY
            key = os.getenv("GOOGLE_API_KEY")
        return key or ""
