from typing import List, Dict, Any
from src.vectorstore import search_similar_chunks, vector_store_exists
from src.logger import get_logger

logger = get_logger(__name__)

class SearchError(Exception):
    """Custom exception raised for search module failures."""
    pass


def perform_semantic_search(
    query: str,
    top_k: int = 5,
    similarity_threshold: float = 0.3,
    api_key: str = None
) -> List[Dict[str, Any]]:
    """
    Performs semantic search against the FAISS vector database.
    Formats the output specifically for presentation in the Semantic Search UI tab.
    
    Returns a list of matching chunks containing:
        - document_name
        - page_number
        - chunk_id
        - score (similarity percentage)
        - text_content
    """
    if not query.strip():
        return []
        
    if not vector_store_exists():
        raise SearchError("No files have been indexed. Please upload PDF files in the sidebar.")
        
    try:
        logger.info(f"Executing semantic search for query: '{query}'...")
        results = search_similar_chunks(
            query=query,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            api_key=api_key
        )
        
        formatted_results = []
        for doc, score in results:
            formatted_results.append({
                "document_name": doc.metadata.get("source", "Unknown Document"),
                "page_number": doc.metadata.get("page", "N/A"),
                "chunk_id": doc.metadata.get("chunk_id", "N/A"),
                "score": score,
                "text_content": doc.page_content
            })
            
        logger.info(f"Semantic search returned {len(formatted_results)} results.")
        return formatted_results
        
    except Exception as e:
        if isinstance(e, SearchError):
            raise e
        logger.error(f"Error executing semantic search: {str(e)}")
        raise SearchError(f"Semantic search failed: {str(e)}")
