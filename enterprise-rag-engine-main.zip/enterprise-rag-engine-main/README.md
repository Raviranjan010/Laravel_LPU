# ContextFlow AI — Enterprise RAG Document Assistant

ContextFlow AI is a production-grade, containerized Retrieval-Augmented Generation (RAG) Document Assistant built using **Python**, **Streamlit**, **LangChain**, **FAISS**, and **Google Gemini 2.5 Flash**. 

Designed as a modern SaaS-style utility, ContextFlow AI allows developers, business analysts, and recruiters to upload single or multiple complex PDFs, chat with them with precise context-aware source citations, execute standalone semantic searches, generate summaries, and monitor analytics.

---

## 🌟 Features

- **Multi-PDF Processing**: Ingest and index multiple PDFs (up to 25MB each) simultaneously. Track upload logs, sizes, page counts, and chunk totals.
- **Strict Citation Engine**: Answers include source file references, page numbers, similarity confidence scores, and actual text snippets to prevent hallucinations.
- **Standalone Semantic Search**: A dedicated search engine tab to directly query raw text chunk embeddings and retrieve match percentages.
- **Automated Document Profiler**: Instantly generate detailed outlines, executive summaries, takeaways, and topics for any ingested document.
- **Analytics Dashboard**: Custom glassmorphism metric cards representing session duration, message volumes, total pages, chunk counts, and file lists.
- **Conversational Memory**: Maintains short-term memory across conversation histories enabling complex follow-up questions.
- **Data Portability**: Download and export entire chat histories in Markdown (`.md`) or plain text (`.txt`) layouts.
- **Free Stack Architecture**: Built completely on free-tier components utilizing Google AI Studio keys (`gemini-2.5-flash` and `text-embedding-004`).

---

## 🏗️ Architecture Design

The following diagram illustrates how user requests, ingestion stages, database updates, and RAG query flows coordinate:

```mermaid
flowchart TD
    subgraph Client Panel (Streamlit UI)
        A[User Input / Queries]
        B[PDF Document Uploads]
    end

    subgraph Data Ingestion Pipeline
        B --> C[File Size & PDF Type Validator]
        C --> D[PyPDF Page Text Extractor]
        D --> E[Recursive Text Splitter]
        E --> F[Google Gemini Embeddings text-embedding-004]
        F --> G[(FAISS Vector Database)]
    end

    subgraph RAG Retrieval & Inference
        A --> H[Semantic Search Module]
        G --> H
        H --> I[Context Format & Injector]
        I --> J[Conversation Memory History]
        J --> K[Gemini 2.5 Flash LLM Client]
        K --> L[Stream Tokens Generator]
        L --> M[Structured Citation Output]
    end
    
    subgraph Analytics & Exports
        G --> N[Analytics Aggregator]
        J --> O[TXT/Markdown Exporters]
    end
```

---

## 📂 Project Structure

```
enterprise-rag-engine/
├── app.py                  # Main Streamlit App Orchestrator
├── requirements.txt        # Production Python Dependencies
├── Dockerfile              # Containerization Recipe
├── docker-compose.yml      # Local Container Orchestration Setup
├── .env.example            # Environment Configurations template
├── .gitignore              # Annotated Git Ignores
├── README.md               # Technical Project Manual
│
├── assets/
│   └── styles.css          # Premium Dark Mode Glassmorphic CSS
│
├── src/
│   ├── config.py           # Paths, Constants, and Model Settings
│   ├── loader.py           # PDF Validation and Chunk Splitter
│   ├── embeddings.py       # Google Gemini Embeddings Handler
│   ├── vectorstore.py      # FAISS Storage and Similarity Searching
│   ├── rag_pipeline.py     # Prompt Compiler and Inference Streaming
│   ├── memory.py           # Streamlit State Memory manager
│   ├── search.py           # Semantic Search API
│   ├── summarizer.py       # Document Outliner API
│   ├── analytics.py        # Analytics Counter logic
│   ├── export.py           # Text/MD Formatter logic
│   ├── logger.py           # Console & Rotating File Logger
│   └── ui.py               # Custom UI Components and Injectors
│
└── tests/
    ├── conftest.py         # Pytest Fixtures
    ├── test_loader.py      # PDF parsing and loader unit tests
    └── test_rag.py         # Memory and search integrations tests
```

---

## ⚙️ Installation & Setup

### Prerequisites
- Python 3.11 or higher installed on your host system.
- A **Google Gemini API Key** (Get one for free at [Google AI Studio](https://aistudio.google.com/)).

### 1. Local Run
Clone the repository and navigate into the folder:
```bash
git clone https://github.com/your-username/enterprise-rag-engine.git
cd enterprise-rag-engine
```

Create a virtual environment and install requirements:
```bash
python -m venv .venv
# On Windows
.venv\Scripts\activate
# On Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

Set up your environment variables:
```bash
copy .env.example .env
# Open '.env' and insert your GEMINI_API_KEY
```

Run the Streamlit app:
```bash
streamlit run app.py
```

---

### 2. Docker Run
You can run the app inside a container immediately using Docker Compose:

Build and start the container:
```bash
docker-compose up --build
```
This loads your local `.env` values, configures ports, mounts persistent storage volumes, and mounts logs. The application will be accessible at `http://localhost:8501`.

---

## 🧪 Testing

The testing suite utilizes `pytest` to validate extraction pipelines, threshold calculations, memory operations, and edge-case exceptions.

Run the tests:
```bash
pytest tests/ -v
```

---

## 🚀 Deployment Guide

### Streamlit Community Cloud
1. Push your repository to GitHub.
2. Visit [Streamlit Share](https://share.streamlit.io/) and log in with GitHub.
3. Click **New app**, select your repository, branch, and set main file path to `app.py`.
4. In **Advanced Settings**, add your API key under Secrets:
   ```toml
   GEMINI_API_KEY = "your_google_studio_key_here"
   ```
5. Click **Deploy!**

---

## 🔒 Security & Performance Features

- **Rate Limit Resilience**: Model interactions include automatic logging and grace exceptions for Gemini's free tier.
- **Input Sanitization**: HTML tags and invalid PDF binary structures are filtered to prevent script injections.
- **Key Shielding**: The application locks API credentials within runtime environments and memory, never outputting them in debug logs.
- **Lazy File Loading**: Memory is optimized by extracting and chunking pages on-the-fly rather than caching raw PDFs.

---

## 📄 License
Distributed under the MIT License. See `LICENSE` for more information.